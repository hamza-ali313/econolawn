<?php
$page = 'Home';
$pageDesc = '""';
include 'includes/header.php';
?>


<!-- inner banner sec start -->
<section class="inner-banner">
    <img src="images/landscaping.png" alt="">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="in-ban">
                    <h1>Gutter Cleaning</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- inner banner sec end -->

<!-- inner services sec start -->
<section class="inner-serv">
    <div class="container">
        <div class="row mt-5 ">
            <div class="col-12 col-lg-5">
                <div>
                    <img src="images/landscaping1.png" alt="" class="landscaping1">
                </div>
            </div>
            <div class="col-12 col-lg-7">
                <div>
                    <h2>LANDSCAPING</h2>
                    <p>
                        Your outdoor space is a canvas waiting to be transformed into a masterpiece. However, creating
                        an aesthetically pleasing and functional landscape requires careful planning, design expertise,
                        and a comprehensive understanding of your unique preferences.
                    </p>
                    <p>
                        Econolawn offers professional landscaping services to turn your outdoor dreams into reality. We
                        believe in going beyond the ordinary, crafting landscapes that not only captivate the eyes but
                        also provide a sanctuary for you to enjoy.
                    </p>
                    <p>
                        Our landscaping service begins with a detailed consultation, where we delve into your vision,
                        preferences, and the natural characteristics of your property. Econolawn’s experienced team then
                        designs and executes a plan that seamlessly integrates hardscapes, greenery, and focal points,
                        ensuring a harmonious and inviting outdoor space.
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5 ">
            <div class="col-12 col-lg-7">
                <div>
                    <h2>BENEFITS:</h2>
                    <p>
                        <span>Personalized Designs:</span> Our landscaping service creates custom designs tailored to
                        your
                        preferences, ensuring a unique and personalized outdoor experience.
                    </p>
                    <p>
                        <span>Functional Spaces:</span> Econolawn considers both aesthetics and functionality,
                        optimizing your
                        outdoor space for relaxation, entertainment, and enjoyment.
                    </p>
                    <p>
                        <span>Increased Property Value:</span> A well-designed landscape not only enhances your living
                        experience but
                        also adds substantial value to your property.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <div>
                    <img src="images/landscaping2.jpg" alt="" class="landscaping2">
                </div>
            </div>
        </div>
        <div class="row mt-5 ">
            <div class="col-12 col-lg-5">
                <div>
                    <img src="images/landscaping3.jpg" alt="" class="landscaping3">
                </div>
            </div>
            <div class="col-12 col-lg-7">
                <div>
                    <h2>FEATURES:</h2>
                    <p>
                        <span>Comprehensive Consultation:</span> We begin with a thorough consultation to understand
                        your vision,
                        preferences, and the unique aspects of your property.
                    </p>
                    <p>
                        <span>Expert Design:</span> Econolawn’s design team combines creativity with practicality to
                        create
                        landscapes that are visually stunning and functionally efficient.
                    </p>
                    <p>
                        <span>Professional Execution:</span> From installing hardscapes to selecting and planting
                        greenery, our team
                        executes the landscaping plan with precision and expertise.
                    </p>
                </div>
            </div>
        </div>
        <p class="mt-5">Transform your outdoor space into a haven of beauty and tranquility. Contact Econolawn for
            expert landscaping
            services that bring your vision to life. Let every step in your garden be a joy with our professional touch
        </p>
    </div>
</section>
<!-- inner services sec end -->

<!-- book services sec start -->
<section class="book-services-form">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div>
                    <h3>Book Services Now</h3>
                    <form action="">
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="firstName" class="form-label">first name</label>
                                    <input type="text" id="firstName" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="Last Name" class="form-label">Last Name</label>
                                    <input type="text" id="Last Name" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="Email Address" class="form-label">Email Address</label>
                                    <input type="text" id="Email Address" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="Business Name" class="form-label">Business Name</label>
                                    <input type="text" id="Business Name" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="Phone Number" class="form-label">Phone Number</label>
                                    <input type="text" id="Phone Number" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="Service Selected" class="form-label">Service Selected</label>
                                    <select class="form-select" aria-label="-select-">
                                        <option selected>-select-</option>
                                        <option value="Landscaping">Landscaping</option>
                                        <option value="Shrub Trimming">Shrub Trimming</option>
                                        <option value="Stump Grinding">Stump Grinding</option>
                                        <option value="Gutter Cleaning">Gutter Cleaning</option>
                                        <option value="Mowing">Mowing</option>
                                        <option value="SNOW SERVICE/REMOVAL">SNOW SERVICE/REMOVAL</option>
                                        <option value="Weed Control">Weed Control</option>
                                        <option value="Sprinkler Blow Out">Sprinkler Blow Out</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="From where they heard about us" class="form-label">From where they heard
                                        about us
                                    </label>
                                    <input type="text" id="From where they heard about us" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="firstName" class="form-label">
                                        Physical address
                                    </label>
                                    <input type="text" id="firstName" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div>
                                    <label for="firstName" class="form-label">
                                        Square footage
                                    </label>
                                    <input type="text" id="firstName" class="form-control">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="upload">
                                    <label for="upload" class="form-label">
                                        Lawn, Drive-way & landscaping Picture
                                    </label>
                                    <input type="file" id="upload" class="form-control">
                                    <button class="btn4">
                                        upload
                                    </button>
                                </div>
                            </div>
                            <div class="col-12 col-lg-12">
                                <div>
                                    <label for="firstName" class="form-label">Message box</label>
                                    <textarea class="form-control" id="floatingTextarea2"
                                        style="height: 100px"></textarea>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="submit" class="btn4">
                                    submit form
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- book services sec end -->





<?php
include 'includes/footer.php';
?>